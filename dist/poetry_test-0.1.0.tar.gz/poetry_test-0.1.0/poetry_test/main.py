from loguru import logger
from wrapper import PoetryTest

if __name__ == "__main__": 
    list_data = ["TELO"]
    poetry_test = PoetryTest(datas=list_data)
    poetry_test.run()